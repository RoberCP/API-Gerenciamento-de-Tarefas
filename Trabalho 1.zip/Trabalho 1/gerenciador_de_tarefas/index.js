const express = require('express');
const app = express();
const routes = require('./routes');
const db = require('./database');
const taskModel = require('./taskModel');
const categoryModel = require('./categoryModel'); // Importando o modelo de categorias

// Criando as tabelas ao iniciar o servidor
taskModel.createTaskTable();
categoryModel.createCategoryTable();

app.use(express.json());
app.use('/api', routes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  
  // Testar conexão com o banco de dados
  db.serialize(() => {
    console.log('Conexão com o banco de dados estabelecida com sucesso.');
  });

  // Lidar com erros de conexão com o banco de dados
  db.on('error', (err) => {
    console.error('Erro ao conectar ao banco de dados:', err);
  });
});

const db = require('./database');

module.exports = {
  createCategoryTable: () => {
    db.serialize(() => {
      db.run(`CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY,
        name TEXT
      )`);
    });
  },

  getAllCategories: () => {
    return new Promise((resolve, reject) => {
      db.all('SELECT * FROM categories', (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  },

  createCategory: (name) => {
    return new Promise((resolve, reject) => {
      db.run('INSERT INTO categories (name) VALUES (?)',
        [name],
        function (err) {
          if (err) {
            reject(err);
          } else {
            resolve({ id: this.lastID });
          }
        });
    });
  },

  updateCategory: (id, name) => {
    return new Promise((resolve, reject) => {
      db.run('UPDATE categories SET name = ? WHERE id = ?',
        [name, id],
        function (err) {
          if (err) {
            reject(err);
          } else {
            resolve({ changes: this.changes });
          }
        });
    });
  },

  deleteCategory: (id) => {
    return new Promise((resolve, reject) => {
      db.run('DELETE FROM categories WHERE id = ?',
        [id],
        function (err) {
          if (err) {
            reject(err);
          } else {
            resolve({ changes: this.changes });
          }
        });
    });
  }
};

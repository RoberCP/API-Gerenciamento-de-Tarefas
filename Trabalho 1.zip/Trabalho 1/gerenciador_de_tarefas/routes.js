const express = require('express');
const router = express.Router();
const taskModel = require('./taskModel');
const categoryModel = require('./categoryModel'); // Importando o modelo de categorias

// Rotas para Tarefas

// Rota para obter todas as tarefas
router.get('/tasks', async (req, res) => {
  try {
    const tasks = await taskModel.getAllTasks();
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rota para criar uma nova tarefa
router.post('/tasks', async (req, res) => {
  const { title, description, status } = req.body;
  try {
    const newTask = await taskModel.createTask(title, description, status);
    res.status(201).json(newTask);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rota para atualizar uma tarefa existente
router.put('/tasks/:id', async (req, res) => {
  const { id } = req.params;
  const { title, description, status } = req.body;
  try {
    const updatedTask = await taskModel.updateTask(id, title, description, status);
    res.json(updatedTask);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rota para excluir uma tarefa
router.delete('/tasks/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const deletedTask = await taskModel.deleteTask(id);
    res.json(deletedTask);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rotas para Categorias

// Rota para obter todas as categorias
router.get('/categories', async (req, res) => {
  try {
    const categories = await categoryModel.getAllCategories();
    res.json(categories);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rota para criar uma nova categoria
router.post('/categories', async (req, res) => {
  const { name } = req.body;
  try {
    const newCategory = await categoryModel.createCategory(name);
    res.status(201).json(newCategory);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rota para atualizar uma categoria existente
router.put('/categories/:id', async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  try {
    const updatedCategory = await categoryModel.updateCategory(id, name);
    res.json(updatedCategory);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rota para excluir uma categoria
router.delete('/categories/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const deletedCategory = await categoryModel.deleteCategory(id);
    res.json(deletedCategory);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

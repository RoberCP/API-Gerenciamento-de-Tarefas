const db = require('./database');

module.exports = {
  createTaskTable: () => {
    db.serialize(() => {
      db.run(`CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY,
        title TEXT,
        description TEXT,
        status TEXT
      )`);
    });
  },

  getAllTasks: () => {
    return new Promise((resolve, reject) => {
      db.all('SELECT * FROM tasks', (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  },

  createTask: (title, description, status) => {
    return new Promise((resolve, reject) => {
      db.run('INSERT INTO tasks (title, description, status) VALUES (?, ?, ?)',
        [title, description, status],
        function (err) {
          if (err) {
            reject(err);
          } else {
            resolve({ id: this.lastID });
          }
        });
    });
  },

  updateTask: (id, title, description, status) => {
    return new Promise((resolve, reject) => {
      db.run('UPDATE tasks SET title = ?, description = ?, status = ? WHERE id = ?',
        [title, description, status, id],
        function (err) {
          if (err) {
            reject(err);
          } else {
            resolve({ changes: this.changes });
          }
        });
    });
  },

  deleteTask: (id) => {
    return new Promise((resolve, reject) => {
      db.run('DELETE FROM tasks WHERE id = ?',
        [id],
        function (err) {
          if (err) {
            reject(err);
          } else {
            resolve({ changes: this.changes });
          }
        });
    });
  }
};
